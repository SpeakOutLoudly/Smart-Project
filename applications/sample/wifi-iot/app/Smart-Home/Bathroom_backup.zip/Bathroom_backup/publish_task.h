#ifndef __PUBLISH_TASK_H__
#define __PUBLISH_TASK_H__

void publish_task(void);

#endif