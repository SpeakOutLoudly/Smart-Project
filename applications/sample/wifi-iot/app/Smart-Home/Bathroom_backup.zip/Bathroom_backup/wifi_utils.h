#ifndef __WIFI_UTILS__
#define __WIFI_UTILS__

void connect_wifi(void);

#endif